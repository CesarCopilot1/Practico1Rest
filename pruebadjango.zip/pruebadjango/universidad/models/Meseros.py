from django.db import models

class Mesero(models.Model):
    nombre = models.CharField(max_length=100)  # Nombre del plato
    apellido = models.CharField(max_length=100)  # Descripción del plato
    telefono = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre
