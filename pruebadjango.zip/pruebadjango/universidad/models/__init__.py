from .docente import Docente
from .materia import Materia
from .alumno import Alumno
from .perfil_alumno import PerfilAlumno


from .Clientes import Cliente
from .Platos import Plato
from .Mesas import Mesa
from .Meseros import Mesero
from .Ordenes import Orden
