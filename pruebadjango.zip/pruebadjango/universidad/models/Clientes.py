from django.db import models



class Cliente(models.Model):
    nombre = models.CharField(max_length=100)
    nit = models.CharField(max_length=20)  # Puedes ajustar el tamaño según el formato del NIT


    def __str__(self):
        return self.nombre
