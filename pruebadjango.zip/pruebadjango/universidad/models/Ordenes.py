from django.db import models

from universidad.models import Cliente, Mesero, Mesa, Plato


class Orden(models.Model):
    ESTADOS = [
        (True, 'Abierta'),
        (False, 'Cerrada')
    ]

    cliente = models.ForeignKey(Cliente, on_delete=models.SET_NULL, null=True, blank=True)
    mesero = models.ForeignKey(Mesero, on_delete=models.CASCADE)
    mesa = models.ForeignKey(Mesa, on_delete=models.CASCADE)  # Una orden por mesa a la vez
    platos = models.ForeignKey(Plato, on_delete=models.CASCADE)
    estado = models.BooleanField(choices=ESTADOS, default=True)
    fecha_hora = models.DateTimeField(auto_now_add=True)
    numero = models.IntegerField()

    def __str__(self):
        return self.numero
