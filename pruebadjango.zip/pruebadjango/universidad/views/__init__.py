from .alumno_views import (alumnosupdate, alumnosdelete,
                           alumnoslist, alumnoscreate)
from .test_views import hola, index
from .materia_views import (
    materia_create, materia_list, materias_delete, materias_edit
)
from .docente_views import DocenteListView, DocenteCreateView, DocenteUpdateView, DocenteDeleteView

from .mesa_view import mesaslist, mesascreate,mesasdelete, mesasupdate
from .plato_view import platoslist,platoscreate,platosdelete,platosupdate
from .mesero_view import meseroslist,meseroscreate, meserosdelete,meserosupdate
from .cliente_view import clienteslist, clientescreate, clientesdelete, clientesupdate
from .ordenes_view import ordeneslist, ordenescreate, ordenesdelete, ordenesupdate
