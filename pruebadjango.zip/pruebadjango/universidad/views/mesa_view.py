from django.shortcuts import render, redirect

from universidad.forms import MesaForm
from universidad.models import Mesa


def mesaslist(request):
    mesas = Mesa.objects.all()
    return render(request, "universidad/mesas/list.html", {"mesas": mesas})


def mesascreate(request):
    form = MesaForm()  # Asegúrate de crear el formulario MesaForm

    if request.method == "POST":
        form = MesaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("mesas_list")

    return render(
        request,
        "universidad/mesas/form.html",  # Asegúrate de crear este archivo de plantilla
        {"form": form}
    )


def mesasupdate(request, id):
    mesa = Mesa.objects.get(id=id)
    if request.method == "POST":
        form = MesaForm(request.POST, instance=mesa)
        if form.is_valid():
            form.save()
            return redirect("mesas_list")

    form = MesaForm(instance=mesa)
    return render(request, "universidad/mesas/form.html", {"form": form})



def mesasdelete(request, id):
    mesa = Mesa.objects.get(id=id)
    mesa.delete()
    return redirect("mesas_list")
