from django.shortcuts import render, redirect

from universidad.forms import OrdenForm
from universidad.models import Orden, Cliente, Mesero, Mesa, Plato


def ordeneslist(request):
    ordenes = Orden.objects.all()
    return render(request, "universidad/ordenes/list.html", {"ordenes": ordenes})


def ordenescreate(request):
    form = OrdenForm()  # Asegúrate de crear el formulario OrdenForm

    if request.method == "POST":
        form = OrdenForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("ordenes_list")

    return render(
        request,
        "universidad/ordenes/form.html",  # Asegúrate de crear este archivo de plantilla
        {"form": form}
    )



def ordenesupdate(request, id):
    orden = Orden.objects.get(id=id)
    if request.method == "POST":
        cliente_id = request.POST.get("cliente")
        mesero_id = request.POST.get("mesero")
        mesa_id = request.POST.get("mesa")
        platos_ids = request.POST.getlist("platos")
        estado = request.POST.get("estado") == "True"
        numero = request.POST.get("numero")

        orden.cliente = Cliente.objects.get(id=cliente_id) if cliente_id else None
        orden.mesero = Mesero.objects.get(id=mesero_id)
        orden.mesa = Mesa.objects.get(id=mesa_id)
        orden.estado = estado
        orden.numero = numero

        orden.platos.clear()
        for plato_id in platos_ids:
            plato = Plato.objects.get(id=plato_id)
            orden.platos.add(plato)

        orden.save()
        return redirect("ordenes")

    clientes = Cliente.objects.all()
    meseros = Mesero.objects.all()
    mesas = Mesa.objects.all()
    platos = Plato.objects.all()

    return render(request, "universidad/ordenes/form.html", {
        "orden": orden,
        "clientes": clientes,
        "meseros": meseros,
        "mesas": mesas,
        "platos": platos
    })


def ordenesdelete(request, id):
    orden = Orden.objects.get(id=id)
    orden.delete()
    return redirect("ordenes")
