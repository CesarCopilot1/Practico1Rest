from django.shortcuts import render, redirect

from universidad.forms import PlatoForm
from universidad.models import Plato


def platoslist(request):
    platos = Plato.objects.all()
    return render(request, "universidad/platos/list.html", {"platos": platos})


def platoscreate(request):
    form = PlatoForm()  # Asegúrate de crear el formulario PlatoForm

    if request.method == "POST":
        form = PlatoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("platos_list")

    return render(
        request,
        "universidad/platos/form.html",  # Asegúrate de crear este archivo de plantilla
        {"form": form}
    )


def platosupdate(request, id):
    plato = Plato.objects.get(id=id)
    if request.method == "POST":
        form = PlatoForm(request.POST, instance=plato)
        if form.is_valid():
            form.save()
            return redirect("platos_list")

    form = PlatoForm(instance=plato)
    return render(request, "universidad/platos/form.html", {"form": form})



def platosdelete(request, id):
    plato = Plato.objects.get(id=id)
    plato.delete()
    return redirect("platos_list")
