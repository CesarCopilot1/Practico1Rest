from django.shortcuts import render, redirect

from universidad.forms import MeseroForm
from universidad.models import Mesero


def meseroslist(request):
    meseros = Mesero.objects.all()
    return render(request, "universidad/meseros/list.html", {"meseros": meseros})


def meseroscreate(request):
    form = MeseroForm()  # Asegúrate de crear el formulario MeseroForm

    if request.method == "POST":
        form = MeseroForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("meseros_list")

    return render(
        request,
        "universidad/meseros/form.html",  # Asegúrate de crear este archivo de plantilla
        {"form": form}
    )


def meserosupdate(request, id):
    mesero = Mesero.objects.get(id=id)
    if request.method == "POST":
        form = MeseroForm(request.POST, instance=mesero)
        if form.is_valid():
            form.save()
            return redirect("meseros_list")

    form = MeseroForm(instance=mesero)
    return render(request, "universidad/meseros/form.html", {"form": form})



def meserosdelete(request, id):
    mesero = Mesero.objects.get(id=id)
    mesero.delete()
    return redirect("meseros_list")
