from django.shortcuts import redirect, render
from universidad.forms import ClienteForm  # Asegúrate de crear el formulario ClienteForm
from universidad.models import Cliente


def clienteslist(request):
    clientes = Cliente.objects.all()
    return render(
        request,
        "universidad/clientes/list.html",  # Asegúrate de crear este archivo de plantilla
        {"clientes": clientes}
    )


def clientescreate(request):
    form = ClienteForm()  # Asegúrate de crear el formulario ClienteForm

    if request.method == "POST":
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("clientes_list")

    return render(
        request,
        "universidad/clientes/form.html",  # Asegúrate de crear este archivo de plantilla
        {"form": form}
    )


def clientesupdate(request, id):
    cliente = Cliente.objects.get(id=id)
    if request.method == "POST":
        form = ClienteForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            return redirect("clientes_list")

    form = ClienteForm(instance=cliente)
    return render(
        request,
        "universidad/clientes/form.html",  # Asegúrate de crear este archivo de plantilla
        {"form": form}
    )


def clientesdelete(request, id):
    cliente = Cliente.objects.get(id=id)
    cliente.delete()
    return redirect("clientes_list")
