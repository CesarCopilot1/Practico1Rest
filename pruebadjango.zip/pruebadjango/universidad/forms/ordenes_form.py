from django import forms
from universidad.models import Orden, Cliente, Mesero, Mesa, Plato

class OrdenForm(forms.ModelForm):


    cliente = forms.ModelChoiceField(
        label="Cliente",
        queryset=Cliente.objects.all(),
        widget=forms.Select(attrs={"class": "form-select"}),
        required=False
    )
    mesero = forms.ModelChoiceField(
        label="Mesero",
        queryset=Mesero.objects.all(),
        widget=forms.Select(attrs={"class": "form-select"}),
        required=False
    )
    mesa = forms.ModelChoiceField(
        label="Mesa",
        queryset=Mesa.objects.all(),
        widget=forms.Select(attrs={"class": "form-select"}),
        required=False
    )
    platos = forms.ModelMultipleChoiceField(
        label="Plato",
        queryset=Plato.objects.all(),
        widget=forms.Select(attrs={"class": "form-select"}),
        required=False
    )
    estado = forms.BooleanField(
        label="Estado",
        widget=forms.CheckboxInput(attrs={"class": "form-check-input"}),
        required=False

    )


    numero = forms.IntegerField(
        label="Número de Orden",
        widget=forms.NumberInput(attrs={"class": "form-control"})
    )

    class Meta:
        model = Orden
        fields = ["cliente", "mesero", "mesa", "platos", "estado", "numero"]