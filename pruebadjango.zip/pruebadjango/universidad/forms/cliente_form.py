from django import forms
from universidad.models import Cliente

class ClienteForm(forms.ModelForm):
    nombre = forms.CharField(
        label="Nombre",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )
    nit = forms.CharField(
        label="NIT",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )

    class Meta:
        model = Cliente
        fields = ["nombre", "nit"]
