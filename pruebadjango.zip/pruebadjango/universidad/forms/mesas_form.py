from django import forms
from universidad.models import Mesa

class MesaForm(forms.ModelForm):
    numero = forms.IntegerField(
        label="Número de Mesa",
        widget=forms.NumberInput(attrs={"class": "form-control"})
    )

    class Meta:
        model = Mesa
        fields = ["numero"]
