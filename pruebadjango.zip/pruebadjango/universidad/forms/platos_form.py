from django import forms
from universidad.models import Plato

class PlatoForm(forms.ModelForm):
    nombre = forms.CharField(
        label="Nombre del Plato",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )
    descripcion = forms.CharField(
        label="Descripción",
        widget=forms.Textarea(attrs={"class": "form-control", "rows": 3})
    )

    class Meta:
        model = Plato
        fields = ["nombre", "descripcion"]
