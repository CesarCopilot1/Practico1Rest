from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("hola", views.hola, name="hola"),
    path("alumnos", views.alumnoslist, name="alumnos"),
    path("alumnos/create", views.alumnoscreate, name="alumnoscreate"),

    path("alumnos/<int:id>", views.alumnosupdate, name="alumnosupdate"),
    path("alumnos/<int:id>/delete", views.alumnosdelete, name="alumnosdelete"),

    path("materias", views.materia_list, name="materias_list"),
    path("materias/create", views.materia_create, name="materias_create"),
    path("materias/<int:id>", views.materias_edit, name="materias_edit"),
    path("materias/<int:id>/delete", views.materias_delete, name="materias_delete"),

    path("docentes", views.DocenteListView.as_view(), name="docentes"),
    path("docentes/create", views.DocenteCreateView.as_view(), name="docentescreate"),
    path("docentes/<int:pk>", views.DocenteUpdateView.as_view(), name="docentes_edit"),
    path('docentes/<int:pk>/delete', views.DocenteDeleteView.as_view(), name='docentes_delete'),

    path("mesas", views.mesaslist, name="mesas_list"),
    path("mesas/create", views.mesascreate, name="mesas_create"),
    path("mesas/<int:id>", views.mesasupdate, name="mesas_edit"),
    path("mesas/<int:id>/delete", views.mesasdelete, name="mesas_delete"),

    path("meseros", views.meseroslist, name="meseros_list"),
    path("meseros/create", views.meseroscreate, name="meseros_create"),
    path("meseros/<int:id>", views.meserosupdate, name="meseros_edit"),
    path("meseros/<int:id>/delete", views.meserosdelete, name="meseros_delete"),

    # Platos
    path("platos", views.platoslist, name="platos_list"),
    path("platos/create", views.platoscreate, name="platos_create"),
    path("platos/<int:id>", views.platosupdate, name="platos_edit"),
    path("platos/<int:id>/delete", views.platosdelete, name="platos_delete"),

    # Clientes
    path("clientes", views.clienteslist, name="clientes_list"),
    path("clientes/create", views.clientescreate, name="clientes_create"),
    path("clientes/<int:id>", views.clientesupdate, name="clientes_edit"),
    path("clientes/<int:id>/delete", views.clientesdelete, name="clientes_delete"),

    # Órdenes
    path("ordenes", views.ordeneslist, name="ordenes_list"),
    path("ordenes/create", views.ordenescreate, name="ordenes_create"),
    path("ordenes/<int:id>", views.ordenesupdate, name="ordenes_edit"),
    path("ordenes/<int:id>/delete", views.ordenesdelete, name="ordenes_delete"),
]

